# API Standards

REST over Express + TypeScript. Base path and version: **`/api/v1`** (no other versioning). Resource-oriented, kebab-case, `:xxxId` path params. Socket.IO handles real-time separately (not a REST replacement).

The frontend calls high-level operations; it does not orchestrate internal algorithms.

## Endpoints (all under `/api/v1` unless noted)
| Resource | Endpoints |
|---|---|
| auth | `POST /auth/register` `login` `logout` `refresh` `forgot-password` `reset-password` `verify-email` `resend-verification` · `GET /auth/me` · `PATCH /auth/password` |
| users | `GET` `PATCH /users/me` · `POST /users/:userId/deactivate` |
| providers | `GET /providers` · `GET /providers/:providerId` · `POST /providers` · `PATCH /providers/me` |
| storages | `GET /storages` `/storages/search` `/storages/mine` `/storages/:storageId` · `POST /storages` · `PATCH /storages/:storageId` · `POST /storages/:storageId/activate` `deactivate` |
| storage-availability | `GET /storage-availability` · `POST /storage-availability/check` |
| vehicles | `GET /vehicles` `/vehicles/mine` `/vehicles/:vehicleId` · `POST /vehicles` · `PATCH /vehicles/:vehicleId` · `POST /vehicles/:vehicleId/activate` `deactivate` |
| transport-options | `GET /transport-options` · `POST /transport-options/check` |
| service-requests | `GET /service-requests/mine` `/:requestId` · `POST /service-requests` · `PATCH /service-requests/:requestId` · `POST /service-requests/:requestId/cancel` |
| matching | `POST /matching/search` |
| recommendations | `POST /recommendations` (main farmer operation; rate-limited, `01` §Routing) |
| routes | `POST /routes/shortest` `/routes/to-storage` · `GET /bookings/:bookingId/route` |
| costs | `POST /costs/storage` `/costs/transport` `/costs/calculate` |
| bookings | `GET /bookings/mine` `/bookings/history` `/bookings/:bookingId` `/bookings/:bookingId/status` · `POST /bookings` (requires `Idempotency-Key`) · `PATCH /bookings/:bookingId` · `POST /bookings/:bookingId/approve` `reject` `confirm` `activate` `complete` `cancel` |
| notifications | `GET /notifications` |
| feature-flags | `GET /admin/feature-flags` · `PATCH /admin/feature-flags/:flagKey` (global default) · `PUT /admin/feature-flags/:flagKey/overrides/:scope/:scopeId` `DELETE .../overrides/:scope/:scopeId` (`scope` = `role`\|`provider`\|`user`; `scopeId` is a `role_key` when `scope=role`, a `userId` otherwise) |
| roles | `GET /admin/roles` · `POST /admin/roles` (custom only) · `PATCH /admin/roles/:roleKey` (`403` if system role) · `POST /admin/roles/:roleKey/deactivate` (`403` if system role) · `POST /admin/users/:userId/roles/:roleKey` (assign) · `DELETE /admin/users/:userId/roles/:roleKey` (unassign — `403` if it's the user's structural role) |
| health | `GET /health` `/health/database` (root path) |

Do not invent endpoints outside this table or the current task. Action verbs (`activate`, `approve`, …) are POST sub-paths. **No endpoint performs a hard delete on an entity a booking can reference** — such endpoints are `POST .../deactivate` or a status-changing `PATCH`, never `DELETE`, per `01`/`10`.

## Rules
- `POST /bookings` is the **single** endpoint for creating a booking, regardless of whether it's storage-only, transport-only, or both — the request body's `service_type`/`booking_type` decides which child row(s) get created. There is no `/bookings/storage-only` or `/bookings/transport-only` — never split this into separate endpoints (`00` §Booking scope).
- `POST /recommendations` runs eligibility → matching → route → cost → rank internally and returns ranked deals with: storage cost, transport cost, total cost, route distance, available capacity, provider rating. Own transport: transport cost not applicable, total = storage cost, transport excluded from ranking. Rate-limited per user/IP; route distances are cache-backed (`01` §Routing).
- Transport cost = `base_charge + distance × cost_per_km` (formula: `00`).
- `409 Conflict` = capacity conflict (e.g. 400 kg + 300 kg requested against 500 kg free: only one may succeed).
- `403 Forbidden` = an ownership check failed, a feature flag resolved to disabled for this caller, or a protected-system-role rule was violated (editing/deleting a system role, unassigning a user's structural role) (`01` §Authorization, §Feature Flags, §Roles).
- Booking lifecycle: `requested → approved|rejected → confirmed → active → completed`, plus `cancelled` and `expired` (TTL sweep, `01` §Background Jobs).
- `POST /bookings` requires an `Idempotency-Key` header; a repeated key returns the original response (`01` §Idempotency).
- Business errors are enforced in the backend (unsupported crop, no capacity, unavailable period, no suitable vehicle, invalid state transition, capacity conflict, ownership violation, disabled feature).

## Contract preservation (when touching an existing endpoint)
Keep its path, method, request contract, response contract, error behavior and auth requirements. The existing implementation is the source of truth. Do not add a new response envelope for style, and do not rename fields.

## Domain field names seen in the design
`userId providerId storageId vehicleId requestId bookingId cropType quantity capacity availability storageCost transportCost totalCost`

## Documentation
API docs are generated from Zod schemas (via an OpenAPI generator), not hand-maintained separately from validation — keeps the spec from drifting out of sync with actual request/response shapes.

## Undecided (do not assume; preserve existing behavior)
- Request wrapper; success envelope (`{success,message,data}` is **not** a convention); error envelope; validation-error format; business error codes.
- Status-code matrix (`409` capacity conflict and `403` ownership/feature-flag are defined; the rest is open).
- Pagination (params and metadata).
- Auth response JSON, token field names, token transport (body vs cookie).
- JSON field casing (do not force camelCase or snake_case globally).
- Per-endpoint JSON schemas.
- Socket.IO event names, payloads, connection auth, ack format.
- Paths not yet defined: notifications (unread, mark read, read-all, delete), crops CRUD/search, storage-crop config (nested under storages), reviews, admin, matching result retrieval, provider-side booking list, user get-by-id/list.
